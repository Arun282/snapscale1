# SnapScale Android
Advanced photo editor WebView starter project.
Open in Android Studio and build `app:assembleDebug`.
For production, replace demo authentication with the SnapScale backend and keep admin credentials server-side.
